function Q = calQlate(u,v,dx,dy,order,wdw)
% A Q-te function to calculate 2D-Q: the second (not first) invariant of the velocity gradient tensor.
% sgolay filter of order = 3 and window length = 9

% Check inputs
if ~exist('order','Var') || isempty(order)
    order = 3;
elseif order > 4
    warning('"order" out of range. Using default value "order == 3"');
    order = 3;
end

if order < 3
    if ~exist('wdw','Var') || isempty(wdw)
        wdw = 5;
    elseif ~any([3,5,7,9]==wdw)
        warning(['"wdw" out of range for order ',num2str(order),', or is even integer. Using default value "wdw == 5"']);
        wdw = 5;
    end
elseif order < 5
    if ~exist('wdw','Var') || isempty(wdw)
        wdw = 9;
    elseif ~any([5,7,9]==wdw)
        warning(['"wdw" out of range for order ',num2str(order),', or is even integer. Using default value "wdw == 9"']);
        wdw = 9;
    end
end

g = fetch_coeff(order,wdw);

switch numel(size(u))
    case 2 % For a single frame
        % x-derivative
        for i = size(u,1):-1:1
            dudx(i,:) = conv(u(i,:), 1/(-dx)*g,'same');
            dvdx(i,:) = conv(v(i,:), 1/(-dx)*g,'same');
        end
        % y-derivative
        for j = size(u,2):-1:1
            dudy(:,j) = conv(u(:,j), 1/(-dy)*g,'same');
            dvdy(:,j) = conv(v(:,j), 1/(-dy)*g,'same');
        end

    case 3 % For multiple frames
        for k = size(u,3):-1:1
            % x-derivative
            for i = size(u,1):-1:1
                dudx(i,:,k) = conv(u(i,:,k), 1/(-dx)*g,'same');
                dvdx(i,:,k) = conv(v(i,:,k), 1/(-dx)*g,'same');
            end
            % y-derivative
            for j = size(u,2):-1:1
                dudy(:,j,k) = conv(u(:,j,k), 1/(-dy)*g,'same');
                dvdy(:,j,k) = conv(v(:,j,k), 1/(-dy)*g,'same');
            end
        end
end

% Compute Q
Q = dudx.*dvdy - dudy.*dvdx;

    function g = fetch_coeff(order, wdw)
        % coefficients for first derivative. Taken from Wikipedia
        if order < 3
        G = [
              1,   2,   3,   4,   5,   6,   7,   8,   9; % window size
            nan, nan, nan, nan, nan, nan, nan, nan,  -4; % -4
            nan, nan, nan, nan, nan, nan,  -3, nan,  -3; % -3
            nan, nan, nan, nan,  -2, nan,  -2, nan,  -2; % -2
            nan, nan,  -1, nan,  -1, nan,  -1, nan,  -1; % -1
            nan, nan,   0, nan,   0, nan,   0, nan,   0; %  0
            nan, nan,   1, nan,   1, nan,   1, nan,   1; % +1
            nan, nan, nan, nan,   2, nan,   2, nan,   2; % +2
            nan, nan, nan, nan, nan, nan,   3, nan,   3; % +3
            nan, nan, nan, nan, nan, nan, nan, nan,   4; % +4
            nan, nan,   2, nan,  10, nan,  28, nan,  60 % Normalization
            ];
        elseif order < 5
            G = [
              1,   2,   3,   4,   5,   6,   7,   8,   9; % window size
            nan, nan, nan, nan, nan, nan, nan, nan,  86; % -4
            nan, nan, nan, nan, nan, nan,  22, nan,-142; % -3
            nan, nan, nan, nan,   1, nan, -67, nan,-193; % -2
            nan, nan, nan, nan,  -8, nan, -58, nan,-126; % -1
            nan, nan, nan, nan,   0, nan,   0, nan,   0; %  0
            nan, nan, nan, nan,   8, nan,  58, nan, 126; % +1
            nan, nan, nan, nan,  -1, nan,  67, nan, 193; % +2
            nan, nan, nan, nan, nan, nan, -22, nan, 142; % +3
            nan, nan, nan, nan, nan, nan, nan, nan, -86; % +4
            nan, nan, nan, nan,  12, nan, 252, nan,1188 % Normalization
            ];
        else
            error('Filter order too high. Code not configured for order higher than 4.')
        end

        g = G( (6-floor(wdw/2)):(6+floor(wdw/2)) , wdw)/(G(end,wdw));
    end

end



